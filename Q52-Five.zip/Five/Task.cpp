#include "StdAfx.h"
#include "Task.h"

Task::Task(void)
{
}

Task::~Task(void)
{
}
